## To fill these in:
## 1. Create a twitter account, or log in to your own
## 2. Go to apps.twitter.com and create a developer account
## 3. Create a new application.
## 4.   Fill in a name (must be unique) and a brief description (anything OK), and ANY complete website, e.g. http://programsinformationpeople.org in the website field. And click the box assuring you've read the developer agreement once you read it! (Though in this course we will not be learning concepts that can violate the TOS...)
## 5.   Click "Create your Twitter application"
## 6.   Click on the Keys and Access Tokens tab on the next screen
## 7.   The Consumer Key (API Key) and Consumer Secret (API Secret) should be visible, strings of letters and numbers. Copy those into the strings below for consumer_key and consumer_secret variables.
## 8.   Scroll down. Click "Create my access token" button.
## 9.   You should then be able to scroll and see the Access Token and Access Token Secret (strings of letters/numbers/characters). Copy those into the access_token and access_token_secret variables below, respectively.
## 10. Make sure this file is in the same directory as the tweepy_example file (or any other file) where you import twitter_info!
## 11. (Don't share this file with anyone or push it to a public GitHub repository -- it contains access to your Twitter account!)

consumer_key = ""
consumer_secret = ""
access_token = ""
access_token_secret = ""
